# andbase3x
# Android 开发利器，基本完美包含你想要的一切，包括BLE，HTTP，UI，数据库，主题，STYLE，一大堆常用必备控件，各种算法工具类，直接用于生产上线
# demo 体验下载 https://sj.qq.com/myapp/detail.htm?apkName=com.upu173.upu 有问题欢迎来问
# 移步 https://gitee.com/zhaoqp/andbase  体验最新版本
