package com.andbase.library.http.model;

/**
 * Copyright upu173.com
 * Author 还如一梦中
 * Date 2016/6/14 17:54
 * Email 396196516@qq.com
 * Info JSON结果
 */

public abstract class AbJsonParams {
	
	public abstract String getJson();

}
