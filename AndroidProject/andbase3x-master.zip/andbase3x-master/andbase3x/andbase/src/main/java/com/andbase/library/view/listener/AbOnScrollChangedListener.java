package com.andbase.library.view.listener;

/**
 * Created by Think on 2017/4/24.
 */

public interface AbOnScrollChangedListener {

    public void onScrollChanged(int left, int top, int oldLeft, int oldTop);

}