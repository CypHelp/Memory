package com.andbase.library.view.recycler;

import android.support.v7.widget.RecyclerView;
import android.view.View;

public class AbHeaderRecyclerViewHolder extends RecyclerView.ViewHolder {
    public final View itemView;
    public AbHeaderRecyclerViewHolder(View view) {
        super(view);
        itemView = view;
    }
}
