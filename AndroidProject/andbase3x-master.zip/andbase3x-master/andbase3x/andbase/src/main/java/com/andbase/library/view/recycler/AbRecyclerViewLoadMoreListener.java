package com.andbase.library.view.recycler;

public interface AbRecyclerViewLoadMoreListener {
    void loadMore(int page);
}
