package com.andbase.library.view.tabs;

/**
 * ================================================
 * 作    者：sufly0001@gmail.com
 * 版    本：1.0
 * 创建日期：2015/10/25
 * 描    述：tab监听回调
 * 修订历史：
 * ================================================
 */
public interface OnTabChangedListner {
    void onTabSelected(int tabNum);
}
