package com.ab.activity.listener;

import java.util.List;

/**
 * Created by wolf on 2015/11/4.
 */
public interface ImageListener {

    void allImages(List<String> paths);
}
