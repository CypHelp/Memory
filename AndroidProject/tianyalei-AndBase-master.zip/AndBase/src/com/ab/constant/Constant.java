package com.ab.constant;

import com.ab.activity.listener.ImageListener;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by wolf on 2015/11/18.
 */
public class Constant {
    public static Map<Integer, ImageListener> imageListenerMap = new HashMap<>();
}
