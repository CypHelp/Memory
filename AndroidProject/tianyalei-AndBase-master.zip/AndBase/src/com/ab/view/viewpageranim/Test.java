package com.ab.view.viewpageranim;


public class Test {
//	mViewPager.setOffscreenPageLimit(2);
//	mViewPager.setPageTransformer(true, new CubeTransformer());
}
